define({ 

 //Type your controller code here 
  getGuestDetails: function(){
    voltmx.print("Entered into Visitors Coount....");
    var visitors_inputParam = visitors_inputParam || {};
    
    visitors_inputParam["serviceID"] = "pgadmin$guests$get";
    visitors_inputParam["options"] = {
      "access"   : "online",
      "CRUD_TYPE": "get"
    };
    var visitors_httpheaders = {};
    visitors_inputParam["httpheaders"] = visitors_httpheaders;
    
    var visitors_httpconfigs = {};
    visitors_inputParam["httpconfig"] = visitors_httpconfigs;
  
 pgadmin$guests$get =
   mfobjectsecureinvokerasync(visitors_inputParam,
                                  "pgadmin",
                                  "guests",
                            (response)=>{
       voltmx.print("Response:+++++++++++++ " + JSON.stringify(response));//data
   var obj = JSON.stringify(response.records);
   voltmx.print("Records :"+response.records);//[object object]
   let dataa= response.records[0];
   
          voltmx.print("Guest Names :"+dataa.guestname);
   
   
   response.records.map(data=>{
        voltmx.print("Guest Names "+data.guestname);
     
     this.view.flxMain.flxguestblock.flxOne.lblGuestName;
     
   })
   });
  
  }
  
  
 });
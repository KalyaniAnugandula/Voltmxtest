define({ 

 //Type your controller code here 
  getVisitorsCount: function(){
    voltmx.print("Entered into Visitors Coount....");
    var visitors_inputParam = visitors_inputParam || {};
    
    visitors_inputParam["serviceID"] = "pgadmin$event_invitations$get";
    visitors_inputParam["options"] = {
      "access"   : "online",
      "CRUD_TYPE": "get"
    };
    var visitors_httpheaders = {};
    visitors_inputParam["httpheaders"] = visitors_httpheaders;
    
    var visitors_httpconfigs = {};
    visitors_inputParam["httpconfig"] = visitors_httpconfigs;
  
 pgadmin$event_invitations$get =
   mfobjectsecureinvokerasync(visitors_inputParam,
                                  "pgadmin",
                                  "event_invitations",
                            (response)=>{
       voltmx.print("Response:+++++++++++++ " + JSON.stringify(response));//data
   var obj = JSON.stringify(response.records);
   voltmx.print("Records :"+response.records);//[object object]
   voltmx.print("Date :" +response.records[0].EventDate);
                 var collection = [];
        var today = new Date();
var  presentDate= new Date(today.getFullYear() , 
today.getMonth());
//    var  presentDate1= new Date(today.getFullYear() , 
// today.getMonth(),today.getDate()-1);
//    voltmx.print(presentDate1+"Present Date 1");
var formattedDate=presentDate.toISOString().split('T')[0].slice(0,7); //yyyy -
// var formattedDate6=presentDate.toISOString().split('T')[0];
// var formattedDate5=presentDate.toISOString().split('T')[0].slice(4,6); //yyyy -mm
// voltmx.print(formattedDate6+"formatted date 6");

// voltmx.print(formattedDate5+"formatted date 5");
// Get the components of the date and time
let year = presentDate.getFullYear();
let month = (presentDate.getMonth() + 1).toString().
padStart(2, '0'); // Months are 0-based, so add 1
let day = today.getDate() < 10 ? '0' + 
    today.getDate() : today.getDate().toString().padStart(2, '0');
let hours = presentDate.getHours().toString().padStart(2, '0');
let minutes = presentDate.getMinutes().toString().padStart(2, '0');
let seconds = presentDate.getSeconds().toString().padStart(2, '0');
let milliseconds = presentDate.getMilliseconds().toString().padStart(3, '0');
voltmx.print(day+"day");
   let day2 = (today.getDate()).toString().padStart(2, '0');
voltmx.print(day2+"day2");

// Combine into the desired format
// let formattedDate7 = `${year}-${month}-${day}`;
   var formattedDate7 = today.toISOString().split('.')[0] + 'Z';
//    voltmx.print();

voltmx.print(formattedDate7+"formtted date 7 ");
let formattedDate4 = `${year}-${month}-${day}T${hours}:${minutes}
:${seconds}.${milliseconds}Z`;
let formattedDate5 = `${year}-${month}-${day2}`;
voltmx.print(formattedDate5+"formtted date 5 ");

   var formattedDate1 = today.toISOString().split('T')[0];  // "YYYY-MM-DD"
voltmx.print("formattedDate1>>>"+formattedDate1);
     voltmx.print(formattedDate+"  Formatted Date");
     
// Adjust for the 0-based month index by adding 1 to the month
var currentMonth = today.getMonth() + 1; 
// Adding 1 to get the correct month (1-12)
// Format the current month and year
var finalFormattedDate = today.getFullYear() + '-' + 
    (currentMonth < 10 ? '0' + currentMonth : currentMonth);
   var finalFormattedDate2= today.getFullYear() + '-' + 
             (currentMonth < 10 ? '0' + currentMonth : currentMonth) + '-' + 
             (today.getDate() < 10 ? '0' + today.getDate() : today.getDate());
     var monthcount=0;
     var weekcount = 0; 
   var daycount =0;
voltmx.print(finalFormattedDate + " Final Formatted Date");
   response.records.map(data=>{
     voltmx.print(data.eventdate);
     var datefromfoundry=data.eventdate;
voltmx.print(datefromfoundry+"datefromfoundry...");
//voltmx.print(datefromfoundry2+"date from foundry 2");
     var datefrmFoundry1 = datefromfoundry.slice(0,10);
  var datefrmFoundry2= datefromfoundry < 10 ? '0' + 
      datefromfoundry : datefromfoundry;
     voltmx.print(datefrmFoundry2+"date from foundry 2");
     var datefrmFoundry = data.eventdate;
voltmx.print(datefrmFoundry1+"date from foundry 1");

voltmx.print("date from Foundry>>>>>> :"+datefrmFoundry);
     var dates = data.eventdate.slice(0,7);
voltmx.print(dates+"dates");
     if(dates===finalFormattedDate){
       monthcount++;
       
     }
     voltmx.print(monthcount+" :Month count");

    var labelDec= this.view.flxMain.flxSecond.flxVisitors.flx1.lblDecVisitors;
    labelDec.text=monthcount.toString();
     voltmx.print( labelDec+" :month count");
   voltmx.print("First Count Completed!!!");

//    Getting Current Week !!!!!!!
   // Function to get the week number for a given date
voltmx.print(finalFormattedDate2+"final formatted 2.");
voltmx.print(formattedDate4+"final formatted 4>>>>>.");
voltmx.print(datefrmFoundry+"Date form Foundry>.>>>");
   if(datefrmFoundry1 === formattedDate5 ){
     daycount++;
     
   }
    var labelDay= this.view.flxMain.flxSecond.flxVisitors.flx3.lblToday;
    labelDay.text=daycount.toString();
     voltmx.print(daycount+" Day Count ..");
     voltmx.print( labelDay+" :text count today");
  voltmx.print(datefrmFoundry+"date from foundry upto day !!");
     voltmx.print(finalFormattedDate2+" final date formatted2 ");
   
 // Initialize weekcount variable

// Function to get the week number for a given date
function getWeekNumber(date) {
    var startDate = new Date(date.getFullYear(), 0, 1); // First day of the year
    var days = Math.floor((date - startDate) / 
         (24 * 60 * 60 * 1000)); // Days passed since the first day of the year
    var weekNumber = Math.ceil((days + 1) / 7); // Week number (1-based index)
    return weekNumber;
}

// Function to get the week format (Year-Week X)
function getWeekFormat(date) {
     year = date.getFullYear(); // Get the current year
    var weekNumber = getWeekNumber(date); // Get the current week number
    return year + "-Week " + weekNumber;
}

// Function to check if dynamic date is in the current week of the current year
function isDateInCurrentWeek(dynamicDate) {
    // Get today's date
     today = new Date();  // Get the current date

    // Get the current year and current week number
    var currentYear = today.getFullYear();
    var currentWeek = getWeekNumber(today);

    // Get the year and week number from the dynamic date
    var dynamicYear = dynamicDate.getFullYear();
    var dynamicWeek = getWeekNumber(dynamicDate);

    // Generate the week format for today and the dynamic date
    var weekFormat = getWeekFormat(today);
    var weekformatDynamic = getWeekFormat(dynamicDate);
voltmx.print("Week Formatt for today :"+weekFormat);
voltmx.print("Week Formatt for Dynamic Date :"+weekformatDynamic);
  // Compare both the year and week number
    if (weekFormat === weekformatDynamic) {
        return true;
      // The dynamic date is in the current week of the current year
    } else {
        return false; 
      // The dynamic date is not in the current week of the current year
    }
}
var dynamicDate = new Date(datefrmFoundry);
voltmx.print("dynamic date >>>>>"+dynamicDate);
// Check if the dynamic date is in the current week
var result = isDateInCurrentWeek(dynamicDate);

if (result) {
    weekcount++;  // Increment week count if condition is true
   
   voltmx.print("First Count Completed!!!");
    voltmx.print("Week Count: " + weekcount);
    voltmx.print
    ("The dynamic date is in the current week of the current year.");
} else {
    voltmx.print
    ("The dynamic date is NOT in the current week of the current year.");
}
      var labelWeek= this.view.flxMain.flxSecond.flxVisitors.flx2.lblWeek;
    labelWeek.text=weekcount.toString();
     voltmx.print( labelWeek+" :text count");

    
   });
   });
  
  }
  
  
 });